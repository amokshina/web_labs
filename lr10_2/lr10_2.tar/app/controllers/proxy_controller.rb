require 'nokogiri'
require 'open-uri'

class ProxyController < ApplicationController
  before_action :parse_params, only: :output

  def output
    if @v1.to_i > 1000
      render 'proxy/input'
    end

    my_url = URL + "&v1=#{@v1}"
    api_response = URI.open(my_url)

    if @side == 'server'
      @result = xslt_transform(api_response).to_html
    elsif @side == 'client-with-xslt'
      xml_content = insert_browser_xslt(api_response).to_xml
      render xml: xml_content, content_type: 'application/xml', layout: false
      #render inline: "<script>window.open('data:application/xml;base64,#{Base64.strict_encode64(xml_content)}')</script>", layout: false
    else
      # xml_content = api_response.to_xml
      xml_content = api_response.read
      render xml: xml_content, content_type: 'application/xml', layout: false
    end
  end

  private

  URL = 'http://localhost:3000/?format=xml'.freeze
  SERV_TRANS = "#{Rails.root}/public/server_transform.xslt".freeze
  BROWS_TRANS = '/browser_transform.xslt'.freeze

  def parse_params
    @v1 = params[:v1]
    @side = params[:side]
  end

  def xslt_transform(data, transform: SERV_TRANS)
    doc = Nokogiri::XML(data)
    xslt = Nokogiri::XSLT(File.read(transform))
    xslt.transform(doc)
  end

  def insert_browser_xslt(data, transform: BROWS_TRANS)
    doc = Nokogiri::XML(data)
    xslt = Nokogiri::XML::ProcessingInstruction.new(doc, 'xml-stylesheet', 'type="text/xsl" href="' + transform + '"')
    doc.root.add_previous_sibling(xslt)
    doc
  end
end
