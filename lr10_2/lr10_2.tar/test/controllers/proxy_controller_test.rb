require "test_helper"

class ProxyControllerTest < ActionDispatch::IntegrationTest
  test "should get input" do
    get proxy_input_url
    assert_response :success
  end

  test "should get output" do
    get proxy_output_url
    assert_response :success
  end

  test 'returns different results for different input data' do
    get proxy_output_url, params: { v1: '33', side: 'server' }
    result_1 = response.body
    get proxy_output_url, params: { v1: '100', side: 'server' }
    result_2 = response.body
    assert_not_equal result_1, result_2
  end

  test "should calculate on server side" do
    get proxy_output_url, params: {v1:33, side: 'server'}
    assert_response :success
    assert_select 'h1', 'Ответ сервера'
  end

  test 'should calculate on client side' do
    get proxy_output_url, params: {v1:33, side: 'client-with-xslt'}
    assert_response :success
    assert_equal 'application/xml; charset=utf-8', @response.content_type
  end

  test 'should calculate on client side in raw' do
    get proxy_output_url, params: {v1:33, side: 'client'}
    assert_response :success
    assert_equal 'application/xml; charset=utf-8', @response.content_type
    assert_select 'integers[type="array"]' do
      assert_select 'integer[type="integer"]', count: 5
      assert_select 'integer', text: '0'
      assert_select 'integer', text: '1'
      assert_select 'integer', text: '5'
      assert_select 'integer', text: '6'
      assert_select 'integer', text: '25'
    end
  end

end
