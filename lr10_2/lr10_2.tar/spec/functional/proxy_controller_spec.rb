require 'rails_helper'

RSpec.describe ProxyController, type: :request do
  describe '#output' do
    it 'returns different results for different input data' do
      # Stub your API response for testing purposes
      allow(URI).to receive(:open)

      # Test with different input data
      get '/output', params: { v1: '10', side: 'server' }
      result_1 = response.body

      get '/output', params: { v1: '33', side: 'server' }
      result_2 = response.body

      expect(result_1).not_to eq(result_2)
    end

    # Add more tests for other scenarios as needed
  end
end
